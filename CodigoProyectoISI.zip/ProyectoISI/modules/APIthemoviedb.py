import requests

def obtener_informacion_pelicula(nombre_pelicula, api_key):
    # Construir la URL de la API con el nombre de la película y la clave de API
    url = f"https://api.themoviedb.org/3/search/movie?api_key={api_key}&query={nombre_pelicula}"

    # Realizar la solicitud GET a la API
    response = requests.get(url)

    # Verificar si la solicitud fue exitosa
    if response.status_code == 200:
        datos_pelicula = response.json()

        # Verificar si se encontró la película
        if datos_pelicula["total_results"] > 0:
            # Obtener el primer resultado de la lista de películas
            pelicula = datos_pelicula["results"][0]
            titulo = pelicula["title"]
            rating = pelicula["vote_average"]
            imagen = "https://image.tmdb.org/t/p/w500" + pelicula["poster_path"]

            return titulo, rating, imagen
        else:
            return None
    else:
        print("Error al realizar la solicitud a la API de The Movie Database.")
        return None

# Nombre de la película a buscar
"""nombre_pelicula = input("Ingresa el nombre de la película: ")

# Clave de API de The Movie Database
api_key = "0cf8bcf44c54573b1364140cd12ac30f"

# Obtener la información de la película
informacion_pelicula = obtener_informacion_pelicula(nombre_pelicula, api_key)

if informacion_pelicula:
    titulo, rating, imagen = informacion_pelicula
    print("Título:", titulo)
    print("Rating:", rating)
    print("Imagen:", imagen)
else:
    print("No se encontró información para la película especificada.")
"""
